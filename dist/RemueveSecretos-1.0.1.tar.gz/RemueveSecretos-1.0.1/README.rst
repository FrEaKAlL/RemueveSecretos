RemueveSecretos
===============

.. image:: https://img.shields.io/pypi/v/RemueveSecretos.svg
    :target: https://pypi.python.org/pypi/RemueveSecretos
    :alt: Latest PyPI version

.. image:: https://travis-ci.org/kragniz/cookiecutter-pypackage-minimal.png
   :target: https://travis-ci.org/kragniz/cookiecutter-pypackage-minimal
   :alt: Latest Travis CI build status

Remueve o muestra secretos para desarrollo evitando filtrar informacion no deseada en nube

Uso
-----
Registro creado para ocultar información sensible antes de realizar el commit o alguna otra aplicación, el uso de la librería es sobre importación al crear tu propio archivo py y poder hacer la referencia a RemuveSecretos

Installation
------------
La instalación es muy sencilla mediante pip con la siguiente sintaxis
pip install RemueveSecretos

Authors
-------

`RemueveSecretos` was written by `FrEaKAlL <sercal0121@gmail.com>`_.
